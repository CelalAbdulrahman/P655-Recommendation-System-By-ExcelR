# P655 Recommendation System

## GitHub Pages + Streamlit Architecture

- GitHub Pages → Landing page
- Streamlit → ML App

## Deploy Steps
1. Upload files
2. Enable GitHub Pages (root)
3. Deploy Streamlit separately
